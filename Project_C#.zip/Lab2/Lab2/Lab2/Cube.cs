﻿using System;
namespace Lab2
{
    //<summary>
    // Cube class to create Cube objects and handle the area/ volume calculations
    //</summary>
    public class Cube : Shape
    {
        private double edge;

        public override double CalculateArea()
        {
            return Math.Pow(edge, 6);
        }

        public override double CalculateVolume()
        {
            return Math.Pow(edge, 3);
        }

        public override void SetData()
        {
            Console.WriteLine("Please enter the edge of the Cube:");
            string value = Console.ReadLine();
            if (!value.Equals(""))
                this.edge = Double.Parse(value);
            else
                SetData();
        }

        public override string ToString()
        {

            return string.Format("{0,15} {1,20} {2,30} {3, 40}",
               "Cube",
               "edge:" + edge.ToString(),
               CalculateArea(),
               CalculateVolume());

        }
    }
}
