﻿using System;
namespace Lab2
{

    //<summary>
    // Circle class to create Circle objects and handle the area/ volume calculations
    //</summary>
    public class Circle : Shape
    {
        private double radius;

        public override double CalculateArea()
        {
            return PI * Math.Pow(radius, 2);
        }

        public override double CalculateVolume()
        {
            throw new NotImplementedException();
        }

        public override void SetData()
        {
            Console.WriteLine("Please enter the Radius of the Circle:");
            string value = Console.ReadLine();

            if (!value.Equals(""))
                this.radius = Double.Parse(value);
            else
                SetData();

        }

        public override string ToString()
        {
            return string.Format("{0,15} {1,20} {2,30}",
                "Circle",
                "radius:" + radius.ToString(),
                CalculateArea());
        }
    }
}
