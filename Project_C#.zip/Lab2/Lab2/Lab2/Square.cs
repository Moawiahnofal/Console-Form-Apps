﻿using System;
namespace Lab2
{

    //<summary>
    // Square class to create Square objects and handle the area/ volume calculations
    //</summary>
    public class Square : Shape
    {
        private double side;

        public override double CalculateArea()
        {
            return Math.Pow(side, 2);
        }

        public override double CalculateVolume()
        {
            throw new NotImplementedException();
        }

        public override void SetData()
        {
            Console.WriteLine("Please enter the side of the Square:");
            string value = Console.ReadLine();
            if (!value.Equals(""))
                this.side = Double.Parse(value);
            else
                SetData();
        }

        public override string ToString()
        {
            return string.Format("{0,15} {1,20} {2,30}",
               "Square",
               "side:" + side.ToString(),
               CalculateArea());
        }
    }
}
