﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using Lab2;
/*
@Author Moawiah Nofal - 000875260

constructor: Peter Basl

Date: 2022/10/12

Working on assignment 2 in C# language/ The view
*/
namespace lab2
{

    //<summary>
    //this class is used to create different shapes 
    //</summary>
    internal class Program
    {

        //<summary>
        // used to print list of shapes
        //</summary>
        //<param name="shapes"> shapes </param>
        public static void printShapes(List<Shape> shapes)
        {
            Console.WriteLine("\n");
            Console.WriteLine("{0,15} {1,20} {2,30} {3, 40}", "Shape", "Dimensions", "Area", "Volume");
            Console.WriteLine("---------------------------------------------------------------------------------------------------------------");
            foreach (Shape shape in shapes)
            {
                Console.WriteLine(shape.ToString()+"\n");
            }
        }

        static void Main(string[] args)
        {
            Console.WriteLine("Please choose the one of the shapes.\n");
            Boolean run = true;
            List<Shape> shapes = new List<Shape>();
            while (run)
            {

                Console.WriteLine("\nMENU \n ----------- \n" +
                "(1) - Rectangle\n" +
                "(2) - Square\n" +
                "(3) - Box\n" +
                "(4) - Cube\n" +
                "(5) - Ellipse\n" +
                "(6) - Circle\n" +
                "(7) - Cylinder\n" +
                "(8) - Sphere\n" +
                "(9) - Triangle\n" +
                "(10) - Tetrahedron\n" +
                "(11) - Exit\n" +
                "(12) - Print Shapes\n");

                Console.WriteLine("your option: ");
                string option = Console.ReadLine();
               

                //Error checking for user input
                if (option.Equals("") || int.Parse(option) <= 0 || int.Parse(option) > 12)
                {
                    Console.WriteLine("Please enter a number between 0 - 12\n");

                }

                switch (option)
                {
                    //Rectangle
                    case "1":
                        Rectangle rectangle = new Rectangle();
                        rectangle.SetData();
                        shapes.Add(rectangle);
                        break;

                    //Square
                    case "2":
                        Square square = new Square();
                        square.SetData();
                        shapes.Add(square);
                        break;

                    //Box
                    case "3":
                        Box box = new Box();
                        box.SetData();
                        shapes.Add(box);
                        break;
                    //Cube
                    case "4":
                        Cube cube = new Cube();
                        cube.SetData();
                        shapes.Add(cube);
                        break;
                        
                    //Ellipse     
                    case "5":
                        Ellipse ellipse = new Ellipse();
                        ellipse.SetData();
                        shapes.Add(ellipse);
                        break;
                    //Circle 
                    case "6":
                        Circle circle = new Circle();
                        circle.SetData();
                        shapes.Add(circle);
                        break;
                    //Cylinder 
                    case "7":
                        Cylinder cylinder = new Cylinder();
                        cylinder.SetData();
                        shapes.Add(cylinder);
                        break;
                    //Sphere 
                    case "8":
                        Sphere sphere = new Sphere();
                        sphere.SetData();
                        shapes.Add(sphere);
                        break;
                    //Cylinder 
                    case "9":
                        Triangle triangle = new Triangle();
                        triangle.SetData();
                        shapes.Add(triangle);
                        break;
                    //Tetrahedron 
                    case "10":
                        Tetrahedron tetrahedron = new Tetrahedron();
                        tetrahedron.SetData();
                        shapes.Add(tetrahedron);
                        break;
                    // Exit
                    case "11":
                        run = false;
                        break;
                    case "12":
                        printShapes(shapes);
                        break;
                }
            }
        }
    }
}
