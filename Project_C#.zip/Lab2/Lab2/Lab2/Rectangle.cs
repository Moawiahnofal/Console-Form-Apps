﻿using System;
namespace Lab2
{

    //<summary>
    // Rectangle class to create Rectangle objects and handle the area/ volume calculations
    //</summary>
    public class Rectangle : Shape
    {

        private double width, length;

        public override double CalculateArea()
        {
            return length * width;
        }

        public override double CalculateVolume()
        {
            throw new NotImplementedException();
        }

        public override void SetData()
        {
            Console.WriteLine("Please enter the Width and Length of the Rectangle sepertated by space:");
            string[] tokens = Console.ReadLine().Split(' ');

            if (tokens.Length == 2)
            {
                this.width = Double.Parse(tokens[0]);
                this.length = Double.Parse(tokens[1]);
            }

            else
            {
                SetData();
            }

        }

        public override string ToString()
        {
            return string.Format("{0,15} {1,20} {2,30}", "Rectangle", "L:" +
                length.ToString() + ",W:" +
                width.ToString(), CalculateArea());
      
        }
    }
}

