﻿using System;
namespace Lab2
{

    //<summary>
    // Box class to create box objects and handle the area/ volume calculations
    //</summary>
    public class Box : Shape
    {
        private double width, length, height;

        public override double CalculateArea()
        {
            return 2 * length * width + 2 * length * height + 2 * height * width;
        }

        public override double CalculateVolume()
        {
            return length * width * height;
        }

        public override void SetData()
        {
            Console.WriteLine("Please enter the Width,Length and Height of the Box sepertated by space:");
            string[] tokens = Console.ReadLine().Split(' ');

            if (tokens.Length == 3)
            {
                this.width = Double.Parse(tokens[0]);
                this.length = Double.Parse(tokens[1]);
                this.height = Double.Parse(tokens[2]);
            }
            else {
                SetData();
            }

        }

        public override string ToString()
        {
            return string.Format("{0,15} {1,20} {2,30}",
                "Box",
                "L:" + length.ToString() +
                ",W:" + width.ToString() +
                ",h:" + height.ToString()
               , CalculateArea());

        }
    }
}
