﻿using System;
namespace Lab2
{

    //<summary>
    // Triangle class to create Triangle objects and handle the area/ volume calculations
    //</summary>
    public class Triangle : Shape
    {

        private double base_, height;

        public override double CalculateArea()
        {
            return (base_ * height)/2;
        }

        public override double CalculateVolume()
        {
            throw new NotImplementedException();
        }

        public override void SetData()
        {
            Console.WriteLine("Please enter the base and height of the Triangle sepertated by space:");
            string[] tokens = Console.ReadLine().Split(' ');

            if (tokens.Length == 2)
            {
                this.base_ = Double.Parse(tokens[0]);
                this.height = Double.Parse(tokens[1]);
            }

            else
            {
                SetData();
            }

        }

        public override string ToString()
        {
            return string.Format("{0,15} {1,20} {2,30}",
                "Triangle",
                "base:" +
               base_.ToString() + ",h:" +
               height.ToString(),
                CalculateArea());
        }
    }
}