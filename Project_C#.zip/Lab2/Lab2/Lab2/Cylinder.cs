﻿using System;
namespace Lab2
{

    //<summary>
    // Cylinder class to create Cylinder objects and handle the area/ volume calculations
    //</summary>
    public class Cylinder : Shape
    {

        private double radius, height;

        public override double CalculateArea()
        {
            return 2 * PI * radius * height + 2 * PI * radius * 2;
        }

        public override double CalculateVolume()
        {
            return PI * radius * 2 * height;
        }

        public override void SetData()
        {
            Console.WriteLine("Please enter the radius and height of the Cylinder sepertated by space:");
            string[] tokens = Console.ReadLine().Split(' ');

            if (tokens.Length == 2)
            {
                this.radius = Double.Parse(tokens[0]);
                this.height = Double.Parse(tokens[1]);
            }

            else
            {
                SetData();
            }

        }

        public override string ToString()
        {
            return string.Format("{0,15} {1,20} {2,30} {3, 40}",
               "Cylinder",
               "radius:" + radius.ToString() + ",h:" + height.ToString(),
               CalculateArea(),
               CalculateVolume());
        }
    }
}

