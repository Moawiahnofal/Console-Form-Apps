﻿using System;
namespace Lab2
{

    //<summary>
    // Tetrahedron class to create Tetrahedron objects and handle the area/ volume calculations
    //</summary>
    public class Tetrahedron : Shape
    {
        private double edge;

        public override double CalculateArea()
        {
            return Math.Sqrt(3 * Math.Pow(edge, 2));
        }

        public override double CalculateVolume()
        {
            return Math.Pow(edge, 3)/6 * Math.Sqrt(2);
        }

        public override void SetData()
        {
            Console.WriteLine("Please enter the edge of the Tetrahedron:");
            string value = Console.ReadLine();
            if (!value.Equals(""))
                this.edge = Double.Parse(value);
            else
                SetData();
        }

        public override string ToString()
        {

            return string.Format("{0,15} {1,20} {2,30} {3, 40}",
               "Tetrahedron",
               "edge:" + edge.ToString(),
               CalculateArea(),
               CalculateVolume());
        }
    }
}
