﻿using System;
namespace Lab2
{

    //<summary>
    // Ellipse class to create Ellipse objects and handle the area/ volume calculations
    //</summary>
    public class Ellipse : Shape
    {

        private double a,b;

        public override double CalculateArea()
        {
            return PI * a * b;
        }

        public override double CalculateVolume()
        {
            throw new NotImplementedException();
        }

        public override void SetData()
        {
            Console.WriteLine("Please enter the A Axis and B Axis of the Ellipse sepertated by space:");
            string[] tokens = Console.ReadLine().Split(' ');

            if (tokens.Length == 2)
            {
                this.a = Double.Parse(tokens[0]);
                this.b = Double.Parse(tokens[1]);
            }

            else
            {
                SetData();
            }

        }

        public override string ToString()
        {
            return string.Format("{0,15} {1,20} {2,30}", "Rectangle", "a:" +
               a.ToString() + ",b:" +
               b.ToString(),
               CalculateArea());
      
        }
    }
}
