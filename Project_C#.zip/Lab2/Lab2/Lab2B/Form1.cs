/*
@Author Moawiah Nofal - 000875260

constructor: Peter Basl

Date: 2022/10/12

Working on assignment 2B in C# language/ The view
*/
namespace Lab2B
{

    //<summary>
    //this class is used to handle the form events
    //</summary>
    public partial class Form1 : Form
    {

        int hairdreeserPrice = 30;
        double clientTypeDiscount = 0;
        int cutPrice, colorPrice, highlightPrice, extensionPrice = 0;

        public Form1()
        {
            InitializeComponent();
        }

        //<summary>
        // used to handle Jane the hair dresser radion button
        //</summary>
        //<param name="sender"> sender </param>
        //<param name="e"> EventArgs </param>
        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (janeRadioButton.Checked) {
                hairdreeserPrice = 30;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        //<summary>
        // used to handle Laura the hair dresser radion button
        //</summary>
        //<param name="sender"> sender </param>
        //<param name="e"> EventArgs </param>
        private void lauraRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (lauraRadioButton.Checked)
            {
                hairdreeserPrice = 55;
            }
        }

        //<summary>
        // used to handle Pat the hair dresser radion button
        //</summary>
        //<param name="sender"> sender </param>
        //<param name="e"> EventArgs </param>
        private void patRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (patRadioButton.Checked)
            {
                hairdreeserPrice = 45;
            }
        }

        //<summary>
        // used to handle Ron the hair dresser radion button
        //</summary>
        //<param name="sender"> sender </param>
        //<param name="e"> EventArgs </param>
        private void ronRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (ronRadioButton.Checked)
            {
                hairdreeserPrice = 40;
            }
        }

        //<summary>
        // used to handle Sue the hair dresser radion button
        //</summary>
        //<param name="sender"> sender </param>
        //<param name="e"> EventArgs </param>
        private void SueRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (SueRadioButton.Checked)
            {
                hairdreeserPrice = 50;
            }
        }

        //<summary>
        // used to handle standard discount radion button
        //</summary>
        //<param name="sender"> sender </param>
        //<param name="e"> EventArgs </param>
        private void standardRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (standardRadioButton.Checked)
            {
                clientTypeDiscount = 0;
            }
        }

        //<summary>
        // used to handle child discount radion button
        //</summary>
        //<param name="sender"> sender </param>
        //<param name="e"> EventArgs </param>
        private void ChildRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (ChildRadioButton.Checked)
            {
                clientTypeDiscount = 10;
            }
        }

        //<summary>
        // used to handle student discount radion button
        //</summary>
        //<param name="sender"> sender </param>
        //<param name="e"> EventArgs </param>
        private void studentRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (studentRadioButton.Checked)
            {
                clientTypeDiscount = 5;
            }
        }

        //<summary>
        // used to handle senior discount radion button
        //</summary>
        //<param name="sender"> sender </param>
        //<param name="e"> EventArgs </param>
        private void SeniorRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            if (SeniorRadioButton.Checked)
            {
                clientTypeDiscount = 15;
            }
        }

        //<summary>
        // used to handle cut service checkbox
        //</summary>
        //<param name="sender"> sender </param>
        //<param name="e"> EventArgs </param>
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (cutCheckBox.Checked)
            {
                cutPrice = 30;
            }
            else {
                cutPrice = 0;
            }
        }

        //<summary>
        // used to handle cut colore checkbox
        //</summary>
        //<param name="sender"> sender </param>
        //<param name="e"> EventArgs </param>
        private void colorCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (colorCheckBox.Checked)
            {
                colorPrice = 40;
           
            }
            else
            {
                colorPrice = 0;
            }
        }

       
        private void visitsNumberTextBox_TextChanged(object sender, EventArgs e)
        {
            
        }

        //<summary>
        // used to handle highlight service checkbox
        //</summary>
        //<param name="sender"> sender </param>
        //<param name="e"> EventArgs </param>
        private void highlightCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (highlightCheckBox.Checked)
            {
                highlightPrice = 50;
            }
            else
            {
                highlightPrice = 0;
            }
        }

        //<summary>
        // used to handle clear event button
        //</summary>
        //<param name="sender"> sender </param>
        //<param name="e"> EventArgs </param>
        private void ClearButton_Click(object sender, EventArgs e)
        {
            visitsNumberTextBox.Text = "";
            janeRadioButton.Checked = true;
            standardRadioButton.Checked = true;
            cutCheckBox.Checked = false;
            colorCheckBox.Checked = false;
            highlightCheckBox.Checked = false;
            extensionCheckBox.Checked = false;
            totalPriceLabel.Text = "Total Price:";
        }

        //<summary>
        // used to handle extension service checkbox
        //</summary>
        //<param name="sender"> sender </param>
        //<param name="e"> EventArgs </param>
        private void extensionCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (extensionCheckBox.Checked)
            {
                extensionPrice = 200;
            }
            else
            {
                extensionPrice = 0;
            }
        }


        //<summary>
        // used to calculate the total price button event
        //</summary>
        //<param name="sender"> sender </param>
        //<param name="e"> EventArgs </param>
        private void calculateButton_Click(object sender, EventArgs e)
        {
            int servicePrice = cutPrice + colorPrice + highlightPrice + extensionPrice;
            double clientTypeDiscount_ = clientTypeDiscount/100;
            if (!visitsNumberTextBox.Text.Equals("") && int.Parse(visitsNumberTextBox.Text) > 0)
            {
                if (servicePrice > 0) {
                    double totalPrice_ = (servicePrice +
               hairdreeserPrice) - (servicePrice +
               hairdreeserPrice) * clientTypeDiscount_;
                    double finalPrice = totalPrice_ - (totalPrice_ * calculateNumberVisitsDiscount());
                    totalPriceLabel.Text = "Total Price: " + finalPrice + "$";
                } else {
                    MessageBox.Show("Please select at least one service!");
                }
            }
            else {
                MessageBox.Show("Please enter a positive number of visits");
            }

            
        }

        //<summary>
        // used to calculate the total number of visits discount
        //</summary>
        //<returns> visit discount </return>
        private double calculateNumberVisitsDiscount() {

            double visitDiscount = 0;
            if (int.Parse(visitsNumberTextBox.Text) > 1 && int.Parse(visitsNumberTextBox.Text) < 3) {
                visitDiscount = 0;
            
            }
            else if (int.Parse(visitsNumberTextBox.Text) > 4 && int.Parse(visitsNumberTextBox.Text) < 8)
            {
                visitDiscount = 0.5;

            }
            else if (int.Parse(visitsNumberTextBox.Text) > 9 && int.Parse(visitsNumberTextBox.Text) < 13)
            {
                visitDiscount = 0.1;

            }
            else if (int.Parse(visitsNumberTextBox.Text) > 14)
            {
                visitDiscount = 0.15;

            }
            return visitDiscount;
        }
    }
}