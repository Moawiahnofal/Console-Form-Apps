﻿namespace Lab2B
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lauraRadioButton = new System.Windows.Forms.RadioButton();
            this.SueRadioButton = new System.Windows.Forms.RadioButton();
            this.ronRadioButton = new System.Windows.Forms.RadioButton();
            this.patRadioButton = new System.Windows.Forms.RadioButton();
            this.janeRadioButton = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.extensionCheckBox = new System.Windows.Forms.CheckBox();
            this.highlightCheckBox = new System.Windows.Forms.CheckBox();
            this.colorCheckBox = new System.Windows.Forms.CheckBox();
            this.cutCheckBox = new System.Windows.Forms.CheckBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.SeniorRadioButton = new System.Windows.Forms.RadioButton();
            this.studentRadioButton = new System.Windows.Forms.RadioButton();
            this.ChildRadioButton = new System.Windows.Forms.RadioButton();
            this.standardRadioButton = new System.Windows.Forms.RadioButton();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.visitsNumberTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.totalPriceLabel = new System.Windows.Forms.Label();
            this.calculateButton = new System.Windows.Forms.Button();
            this.ClearButton = new System.Windows.Forms.Button();
            this.ExitButton = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.groupBox1.Controls.Add(this.lauraRadioButton);
            this.groupBox1.Controls.Add(this.SueRadioButton);
            this.groupBox1.Controls.Add(this.ronRadioButton);
            this.groupBox1.Controls.Add(this.patRadioButton);
            this.groupBox1.Controls.Add(this.janeRadioButton);
            this.groupBox1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.groupBox1.Location = new System.Drawing.Point(24, 28);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 172);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Hairdresser";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // lauraRadioButton
            // 
            this.lauraRadioButton.AutoSize = true;
            this.lauraRadioButton.Location = new System.Drawing.Point(20, 121);
            this.lauraRadioButton.Name = "lauraRadioButton";
            this.lauraRadioButton.Size = new System.Drawing.Size(102, 19);
            this.lauraRadioButton.TabIndex = 1;
            this.lauraRadioButton.Text = "Laura Renkins";
            this.lauraRadioButton.UseVisualStyleBackColor = true;
            this.lauraRadioButton.CheckedChanged += new System.EventHandler(this.lauraRadioButton_CheckedChanged);
            // 
            // SueRadioButton
            // 
            this.SueRadioButton.AutoSize = true;
            this.SueRadioButton.Location = new System.Drawing.Point(20, 96);
            this.SueRadioButton.Name = "SueRadioButton";
            this.SueRadioButton.Size = new System.Drawing.Size(82, 19);
            this.SueRadioButton.TabIndex = 3;
            this.SueRadioButton.Text = "Sue Pallon";
            this.SueRadioButton.UseVisualStyleBackColor = true;
            this.SueRadioButton.CheckedChanged += new System.EventHandler(this.SueRadioButton_CheckedChanged);
            // 
            // ronRadioButton
            // 
            this.ronRadioButton.AutoSize = true;
            this.ronRadioButton.Location = new System.Drawing.Point(20, 71);
            this.ronRadioButton.Name = "ronRadioButton";
            this.ronRadioButton.Size = new System.Drawing.Size(105, 19);
            this.ronRadioButton.TabIndex = 2;
            this.ronRadioButton.Text = "Ron Chambers";
            this.ronRadioButton.UseVisualStyleBackColor = true;
            this.ronRadioButton.CheckedChanged += new System.EventHandler(this.ronRadioButton_CheckedChanged);
            // 
            // patRadioButton
            // 
            this.patRadioButton.AutoSize = true;
            this.patRadioButton.Location = new System.Drawing.Point(20, 46);
            this.patRadioButton.Name = "patRadioButton";
            this.patRadioButton.Size = new System.Drawing.Size(91, 19);
            this.patRadioButton.TabIndex = 1;
            this.patRadioButton.Text = "Pat Johnson";
            this.patRadioButton.UseVisualStyleBackColor = true;
            this.patRadioButton.CheckedChanged += new System.EventHandler(this.patRadioButton_CheckedChanged);
            // 
            // janeRadioButton
            // 
            this.janeRadioButton.AutoSize = true;
            this.janeRadioButton.Checked = true;
            this.janeRadioButton.Location = new System.Drawing.Point(20, 21);
            this.janeRadioButton.Name = "janeRadioButton";
            this.janeRadioButton.Size = new System.Drawing.Size(93, 19);
            this.janeRadioButton.TabIndex = 0;
            this.janeRadioButton.TabStop = true;
            this.janeRadioButton.Text = "Jane Samley";
            this.janeRadioButton.UseVisualStyleBackColor = true;
            this.janeRadioButton.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.extensionCheckBox);
            this.groupBox2.Controls.Add(this.highlightCheckBox);
            this.groupBox2.Controls.Add(this.colorCheckBox);
            this.groupBox2.Controls.Add(this.cutCheckBox);
            this.groupBox2.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.groupBox2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.groupBox2.Location = new System.Drawing.Point(266, 28);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(200, 163);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Services";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // extensionCheckBox
            // 
            this.extensionCheckBox.AutoSize = true;
            this.extensionCheckBox.Location = new System.Drawing.Point(16, 98);
            this.extensionCheckBox.Name = "extensionCheckBox";
            this.extensionCheckBox.Size = new System.Drawing.Size(85, 19);
            this.extensionCheckBox.TabIndex = 5;
            this.extensionCheckBox.Text = "Extensions";
            this.extensionCheckBox.UseVisualStyleBackColor = true;
            this.extensionCheckBox.CheckedChanged += new System.EventHandler(this.extensionCheckBox_CheckedChanged);
            // 
            // highlightCheckBox
            // 
            this.highlightCheckBox.AutoSize = true;
            this.highlightCheckBox.Location = new System.Drawing.Point(16, 71);
            this.highlightCheckBox.Name = "highlightCheckBox";
            this.highlightCheckBox.Size = new System.Drawing.Size(82, 19);
            this.highlightCheckBox.TabIndex = 4;
            this.highlightCheckBox.Text = "Highlights";
            this.highlightCheckBox.UseVisualStyleBackColor = true;
            this.highlightCheckBox.CheckedChanged += new System.EventHandler(this.highlightCheckBox_CheckedChanged);
            // 
            // colorCheckBox
            // 
            this.colorCheckBox.AutoSize = true;
            this.colorCheckBox.Location = new System.Drawing.Point(15, 47);
            this.colorCheckBox.Name = "colorCheckBox";
            this.colorCheckBox.Size = new System.Drawing.Size(62, 19);
            this.colorCheckBox.TabIndex = 1;
            this.colorCheckBox.Text = "Colour";
            this.colorCheckBox.UseVisualStyleBackColor = true;
            this.colorCheckBox.CheckedChanged += new System.EventHandler(this.colorCheckBox_CheckedChanged);
            // 
            // cutCheckBox
            // 
            this.cutCheckBox.AutoSize = true;
            this.cutCheckBox.Location = new System.Drawing.Point(16, 26);
            this.cutCheckBox.Name = "cutCheckBox";
            this.cutCheckBox.Size = new System.Drawing.Size(45, 19);
            this.cutCheckBox.TabIndex = 0;
            this.cutCheckBox.Text = "Cut";
            this.cutCheckBox.UseVisualStyleBackColor = true;
            this.cutCheckBox.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.SeniorRadioButton);
            this.groupBox3.Controls.Add(this.studentRadioButton);
            this.groupBox3.Controls.Add(this.ChildRadioButton);
            this.groupBox3.Controls.Add(this.standardRadioButton);
            this.groupBox3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.groupBox3.Location = new System.Drawing.Point(24, 253);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(200, 142);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Client Type";
            // 
            // SeniorRadioButton
            // 
            this.SeniorRadioButton.AutoSize = true;
            this.SeniorRadioButton.Location = new System.Drawing.Point(15, 107);
            this.SeniorRadioButton.Name = "SeniorRadioButton";
            this.SeniorRadioButton.Size = new System.Drawing.Size(115, 19);
            this.SeniorRadioButton.TabIndex = 4;
            this.SeniorRadioButton.Text = "Senior (over 65)";
            this.SeniorRadioButton.UseVisualStyleBackColor = true;
            this.SeniorRadioButton.CheckedChanged += new System.EventHandler(this.SeniorRadioButton_CheckedChanged);
            // 
            // studentRadioButton
            // 
            this.studentRadioButton.AutoSize = true;
            this.studentRadioButton.Location = new System.Drawing.Point(15, 82);
            this.studentRadioButton.Name = "studentRadioButton";
            this.studentRadioButton.Size = new System.Drawing.Size(70, 19);
            this.studentRadioButton.TabIndex = 3;
            this.studentRadioButton.Text = "Student";
            this.studentRadioButton.UseVisualStyleBackColor = true;
            this.studentRadioButton.CheckedChanged += new System.EventHandler(this.studentRadioButton_CheckedChanged);
            // 
            // ChildRadioButton
            // 
            this.ChildRadioButton.AutoSize = true;
            this.ChildRadioButton.Location = new System.Drawing.Point(15, 57);
            this.ChildRadioButton.Name = "ChildRadioButton";
            this.ChildRadioButton.Size = new System.Drawing.Size(136, 19);
            this.ChildRadioButton.TabIndex = 1;
            this.ChildRadioButton.Text = "Child (12 and under)";
            this.ChildRadioButton.UseVisualStyleBackColor = true;
            this.ChildRadioButton.CheckedChanged += new System.EventHandler(this.ChildRadioButton_CheckedChanged);
            // 
            // standardRadioButton
            // 
            this.standardRadioButton.AutoSize = true;
            this.standardRadioButton.Checked = true;
            this.standardRadioButton.Location = new System.Drawing.Point(15, 32);
            this.standardRadioButton.Name = "standardRadioButton";
            this.standardRadioButton.Size = new System.Drawing.Size(106, 19);
            this.standardRadioButton.TabIndex = 0;
            this.standardRadioButton.TabStop = true;
            this.standardRadioButton.Text = "Standard adult";
            this.standardRadioButton.UseVisualStyleBackColor = true;
            this.standardRadioButton.CheckedChanged += new System.EventHandler(this.standardRadioButton_CheckedChanged);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.visitsNumberTextBox);
            this.groupBox4.Controls.Add(this.label1);
            this.groupBox4.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.groupBox4.Location = new System.Drawing.Point(266, 254);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(200, 141);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Client Visits";
            // 
            // visitsNumberTextBox
            // 
            this.visitsNumberTextBox.Location = new System.Drawing.Point(20, 47);
            this.visitsNumberTextBox.Name = "visitsNumberTextBox";
            this.visitsNumberTextBox.Size = new System.Drawing.Size(100, 23);
            this.visitsNumberTextBox.TabIndex = 1;
            this.visitsNumberTextBox.TextChanged += new System.EventHandler(this.visitsNumberTextBox_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(138, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Number of Client Visits:";
            // 
            // totalPriceLabel
            // 
            this.totalPriceLabel.AutoSize = true;
            this.totalPriceLabel.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.totalPriceLabel.Location = new System.Drawing.Point(166, 451);
            this.totalPriceLabel.Name = "totalPriceLabel";
            this.totalPriceLabel.Size = new System.Drawing.Size(68, 15);
            this.totalPriceLabel.TabIndex = 4;
            this.totalPriceLabel.Text = "Total Price:";
            // 
            // calculateButton
            // 
            this.calculateButton.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.calculateButton.Location = new System.Drawing.Point(63, 510);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(75, 23);
            this.calculateButton.TabIndex = 5;
            this.calculateButton.Text = "Calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // ClearButton
            // 
            this.ClearButton.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.ClearButton.Location = new System.Drawing.Point(193, 510);
            this.ClearButton.Name = "ClearButton";
            this.ClearButton.Size = new System.Drawing.Size(75, 23);
            this.ClearButton.TabIndex = 6;
            this.ClearButton.Text = "Clear";
            this.ClearButton.UseVisualStyleBackColor = true;
            this.ClearButton.Click += new System.EventHandler(this.ClearButton_Click);
            // 
            // ExitButton
            // 
            this.ExitButton.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.ExitButton.Location = new System.Drawing.Point(321, 510);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(75, 23);
            this.ExitButton.TabIndex = 7;
            this.ExitButton.Text = "Exit";
            this.ExitButton.UseVisualStyleBackColor = true;
            this.ExitButton.Click += new System.EventHandler(this.button3_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(604, 607);
            this.Controls.Add(this.ExitButton);
            this.Controls.Add(this.ClearButton);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.totalPriceLabel);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Perfect Cut Hair Salon";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private GroupBox groupBox1;
        private RadioButton lauraRadioButton;
        private RadioButton SueRadioButton;
        private RadioButton ronRadioButton;
        private RadioButton patRadioButton;
        private RadioButton janeRadioButton;
        private GroupBox groupBox2;
        private CheckBox checkBox4;
        private CheckBox checkBox3;
        private CheckBox checkBox2;
        private CheckBox checkBox1;
        private GroupBox groupBox3;
        private RadioButton radioButton9;
        private RadioButton radioButton8;
        private RadioButton radioButton7;
        private RadioButton Standards;
        private GroupBox groupBox4;
        private TextBox visitsNumberTextBox;
        private Label label1;
        private Label totalPriceLabel;
        private Button calculateButton;
        private Button ClearButton;
        private Button ExitButton;
        private RadioButton SeniorRadioButton;
        private RadioButton studentRadioButton;
        private RadioButton ChildRadioButton;
        private RadioButton standardRadioButton;
        private CheckBox extensionCheckBox;
        private CheckBox highlightCheckBox;
        private CheckBox colorCheckBox;
        private CheckBox cutCheckBox;
    }
}