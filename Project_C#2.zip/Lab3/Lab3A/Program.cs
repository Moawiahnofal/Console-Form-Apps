﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3A
{
    internal class Program
    {

        const string DATAFILE = "Data.txt";

        //<summary>
        //</summary>
        public static List<Media> ReadData()
        {
            List<Media> mediaList = new List<Media>();

            try
            {
                StreamReader myFile = new StreamReader(DATAFILE);
                string[] lines = File.ReadAllLines(DATAFILE);
                int i = 0;
                foreach (var line in lines)
                {

                    if (i == 100) {
                       break;
                    }
                    String[] col = line.Split('|');
                    if (Convert.ToString(col[0]).Equals("BOOK")) {
                        mediaList[i] = new Book(Convert.ToString(col[1]), Convert.ToInt32(col[2]), Convert.ToString(col[3]), Convert.ToString(col[4]));
                    }
                   else if (Convert.ToString(col[0]).Equals("MOVIE"))
                    {
                        mediaList[i] = new Movie(Convert.ToString(col[1]), Convert.ToInt32(col[2]), Convert.ToString(col[3]), Convert.ToString(col[4]));
                    }
                   else if (Convert.ToString(col[0]).Equals("SONG"))
                    {
                        mediaList[i] = new Song(Convert.ToString(col[1]), Convert.ToInt32(col[2]), Convert.ToString(col[3]), Convert.ToString(col[4]));
                    }
                  
                    i++;

                }

            }
            catch (Exception ex)
            {
                Console.WriteLine("exception conevrting txt into list : " + ex);
            }

            return mediaList;
        }



        public static void printMediaList(List<Media> mediaList)
        {
            foreach (Media media in mediaList)
            {
                    Console.WriteLine(media.ToString() + "\n");
            }

        }

        public static void printBookList(List<Media> mediaList)
        {
            foreach (Media media in mediaList)
            {
                if (media is Book)
                {
                    Console.WriteLine(media.ToString() + "\n");
                }
            }

        }

        public static void printMovieList(List<Media> mediaList)
        {
            foreach (Media media in mediaList)
            {
                if (media is Movie)
                {
                    Console.WriteLine(media.ToString() + "\n");
                }
            }
        }

        public static void printSongList(List<Media> mediaList)
        {
            foreach (Media media in mediaList)
            {
                if (media is Song)
                {
                    Console.WriteLine(media.ToString() + "\n");
                }
            }

        }

        public static void searchMedia(List<Media> mediaList, string title)
        {
            foreach (Media media in mediaList)
            {
                if (media.Search(title))
                {
                    Console.WriteLine(media.ToString() + "\n");
                }
            }

        }
        static void Main(string[] args)
        {
            Console.WriteLine("Please choose one of the following.\n");
            Boolean run = true;
            //List<Media> mediaList = new List<Media>();
            while (run)
            {

                Console.WriteLine("\nMENU \n ----------- \n" +
                "(1) - List All Books\n" +
                "(2) - List All Movies\n" +
                "(3) - List All Songs\n" +
                "(4) - List All Media\n" +
                "(5) - Search All Media by Title\n" +
                "(6) - Exit\n");

                Console.WriteLine("your option: ");
                string option = Console.ReadLine();


                //Error checking for user input
                if (option.Equals("") || int.Parse(option) <= 0 || int.Parse(option) > 7)
                {
                    Console.WriteLine("Please enter a number between 0 - 12\n");

                }

                switch (option)
                {
                    //List All Books
                    case "1":
                        printBookList(ReadData());
                        break;

                    //List All Movies
                    case "2":
                      printMovieList(ReadData());
                        break;

                    //List All Songs
                    case "3":
                       printSongList(ReadData());
                        break;

                    //List All Media
                    case "4":
                        printMediaList(ReadData());
                        break;

                    //Search All Media by Title     
                    case "5":
                        Console.WriteLine("please enter the title: ");
                        string title = Console.ReadLine();
                        searchMedia(ReadData(), title);
                        break;
                    //Exit 
                    case "6":
                        run = false;
                        break;
                  
                }
            }
        }
    }
}
