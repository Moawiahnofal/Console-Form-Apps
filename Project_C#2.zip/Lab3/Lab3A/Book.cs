﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Book : Media, IEncryptable
{
    public string Author { get; protected set; }
    public string Summary { get; protected set; }

    public Book(string title, int year, string author, string summary) : base(title, year)
    {
        Author = author;
        Summary = summary;
    }

    public String Encrypt() {

        return "";
    }

    public String Decrypt()
    {
        return "";
    }

}
