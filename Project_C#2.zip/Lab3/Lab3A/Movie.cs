﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

    internal class Movie : Media
    {

    public string Director { get; protected set; }          
    public string Summary { get; protected set; }             


    public Movie(string title, int year, string director, string summary) : base(title, year)
        {
        Director = director;
        Summary = summary;
        }
    }

